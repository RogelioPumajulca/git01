package com.example.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.entities.Articulo;


@Repository
@Transactional
public interface ArticuloRepository extends CrudRepository<Articulo, Integer> {
  
	
	List<Articulo> findByClavearticuloOrderByPrecioventaDesc(int clavearticulo);
	
	
	@Query("select count(a) from Articulo a where a.clavearticulo=?1")
	int countArticuloClavearticulo(int clavearticulo);
	
	
	@Query("select a from Articulo a where a.precioventa between ?1 and ?2")
	List<Articulo> findByPrecioVenta(double pv1,double pv2);
	
}

