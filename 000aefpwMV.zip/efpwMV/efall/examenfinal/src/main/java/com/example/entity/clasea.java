package com.example.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

@Entity
public class clasea implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	long idclasea;
	
	//tipo de claseb:
	@ManyToOne
	@JoinColumn(name="idclaseb")
	claseb claseb;
	
	@Size(min=1,max=44)
	String nombre;
	
	@Size(min=1,max=44)
	String tipo;
	
	@Min(1)
	@Max(100)
	int cantidad;
	
	@Digits(integer=5,fraction=2)
	double precio;

	public long getIdclasea() {
		return idclasea;
	}

	public void setIdclasea(long idclasea) {
		this.idclasea = idclasea;
	}

	public claseb getClaseb() {
		return claseb;
	}

	public void setClaseb(claseb claseb) {
		this.claseb = claseb;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	
	
	
}
