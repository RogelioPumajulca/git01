package com.example.service;

import com.example.entity.clasea;

public interface claseaService {

	clasea saveclasea(clasea clasea);
	Iterable<clasea> listartodoclasea();
	Iterable<clasea> listarclaseaPorTipo(String tipo);
	Iterable<clasea> listarclaseaPorclasebNombre(String clasebnombre);
	
	
	//no me sale
	Iterable<clasea> listarclaseaPorclaseb(long idclaseb); 
	
}
