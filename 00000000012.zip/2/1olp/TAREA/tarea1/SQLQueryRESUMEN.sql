

drop table STG_ALUMNO
drop table STG_NOTAS
drop table STG_CURSO



create table STG_ALUMNO
(
	sk_alumno int IDENTITY(1,1) NOT NULL,
	codalumno nvarchar(3),
	nombre nvarchar(25),
	ciclo nvarchar(25)
)

create table STG_CURSO
(
	sk_curso int IDENTITY(1,1) NOT NULL,
	codcurso nvarchar(3),
	descripcion nvarchar(25),
)


create table STG_NOTAS
(
	sk_curso int,
	sk_alumno int,
	codCurso nvarchar(3),
	codalumno nvarchar(3),
	nota int ,
	notaApro int,
	porcentaje numeric(3,2)
)



drop table STG_ALUMNO
drop table STG_NOTAS
drop table STG_CURSO


select * from STG_ALUMNO
SELECT * FROM STG_CURSO
select * from STG_NOTAS



