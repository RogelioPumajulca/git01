/****** Object:  StoredProcedure [dbo].[sp_PoblarTablaTiempo]    Script Date: 03/31/2012 07:49:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_PoblarTablaTiempo] AS 
--Borra el contenido de la tabla
--Delete from Stg_Tiempo-- 
--SET LANGUAGE us_english
SET LANGUAGE spanish 

--declare variables
DECLARE @DT DATETIME
DECLARE @A�O INT
DECLARE @TRIMESTRE INT
DECLARE @MES INT
DECLARE @SEMANA INT
DECLARE @DiaDeA�o INT
DECLARE @DiaDeMes INT
DECLARE @DiaDeSemana INT
DECLARE @EsFinSemana int
DECLARE @EsFeriado int
DECLARE @SemanaCalendario INT
DECLARE @SemanasDelA�oLaborales INT
DECLARE @A�oBisiesto TINYINT

DECLARE @Desc_DiaDeSemana varchar(10)
DECLARE @Desc_Mes varchar(10)
DECLARE @Desc_Trimestre varchar(15)
DECLARE @Desc_Fin_Semana varchar(15)
DECLARE @Desc_Quincena_Mes varchar(15) 
--Inicializar variables 
SELECT @SemanasDelA�oLaborales =0
SELECT @SemanaCalendario = 1
SELECT @A�oBisiesto =0 
SELECT @EsFeriado =0
SET @Desc_DiaDeSemana = ''
SET @Desc_Mes = ''
SET @Desc_Trimestre = ''
SET @Desc_Fin_Semana = ''
SET @Desc_Quincena_Mes = '' 
DBCC CHECKIDENT (Stg_Tiempo,RESEED,0)
--Fecha de Inicio para la dimension TIEMPO (D/M/Y), si es espa�ol
SELECT @DT = '01-01-1996' 
--Inicio del LOOP, FINALIZARA hasta este FECHA
WHILE (@DT <= '31-12-2012')
BEGIN 

--conseguir informacion de la DATA
SELECT @EsFinSemana =0
SELECT @A�O = DATEPART (YEAR, @DT)
SELECT @TRIMESTRE = DATEPART (QUARTER, @DT) 
SELECT @MES = DATEPART (MONTH , @DT)
SELECT @SEMANA = DATEPART (WEEK , @DT)
SELECT @DiaDeA�o = DATEPART (DY , @DT)
SELECT @DiaDeMes = DATEPART (DAY , @DT)
SELECT @DiaDeSemana = DATEPART (DW , @DT) 
SELECT @Desc_DiaDeSemana = DateName (dw , @DT)
SELECT @Desc_Mes = DateName (month , @DT)
SELECT @Desc_Trimestre = 'Trimestre' + ' ' + DateName (qq , @DT)
SELECT @Desc_Fin_Semana = Case
when datepart(dw,@DT) in (7,6) then 'Fin Semana'
else 'D�as Utiles'
end
SELECT @Desc_Quincena_Mes = case
when DATEPART (DAY , @DT)<=15 then 'Quincena 1'
else 'Quincena 2'
End 
--Sera fin de semana o no?????
IF ( @DiaDeSemana = 6 OR @DiaDeSemana = 7 ) 
BEGIN
SELECT @EsFinSemana = 1
END 
--Agregar 1 a SEMANA CALENDARIO cada vez que empezamos una nueva semana
IF ( @DiaDeSemana = 1)
BEGIN
SELECT @SemanaCalendario = @SemanaCalendario +1
END 
--Reglas de negocio (Buscamos Semanas completas en un a�o, asi que una semana parcial en un a�o sera 0)
IF ( @DiaDeSemana != 1 AND @DiaDeA�o = 1)
BEGIN
SELECT @SemanasDelA�oLaborales = 0
END 

IF ( @DiaDeSemana = 1)
BEGIN
SELECT @SemanasDelA�oLaborales = @SemanasDelA�oLaborales +1
END 
--Reglas de negocio (Se vuelve a empezar a contar las semanas laborales con la primera semana completa)
IF (@SemanasDelA�oLaborales =53)
BEGIN
SELECT @SemanasDelA�oLaborales = 1
END

IF (@EsFeriado = 1)
BEGIN
SELECT @EsFeriado = 1
END
--Verificar A�o bisiesto
IF ((@A�O % 4 = 0) AND (@A�O % 100 != 0 OR @A�O % 400 = 0))
SELECT @A�oBisiesto =1
ELSE SELECT @A�oBisiesto =0

--Inserta valores en la tabla de dimension TIEMPO

Update Stg_Tiempo
Set Tiempo_Nombre_DiaDeSemana=@Desc_DiaDeSemana,Tiempo_Nombre_Mes=@Desc_Mes,
Tiempo_Nombre_Trimestre=@Desc_Trimestre,Tiempo_Nombre_EsFinSemana=@Desc_Fin_Semana,Tiempo_Nombre_Quincena=@Desc_Quincena_Mes
Where Tiempo_FechaActual=@DT

/*(Tiempo_FechaActual,
 Tiempo_Anio,
 Tiempo_Trimestre,
 Tiempo_Mes,
 Tiempo_Semana,
 Tiempo_DiaDeAnio,
 Tiempo_DiaDeMes,
 Tiempo_DiaDeSemana,
 Tiempo_EsFinSemana,
 Tiempo_EsFeriado,
 Tiempo_SemanaCalendario,
 Tiempo_SemanasDelA�oLaborales,
 Tiempo_AnioBisiesto,
 Tiempo_Nombre_DiaDeSemana,
 Tiempo_Nombre_Mes,
 Tiempo_Nombre_Trimestre,
 Tiempo_Nombre_EsFinSemana,
 Tiempo_Nombre_Quincena)
VALUES (@DT, @A�O, @TRIMESTRE, @MES, @SEMANA, @DiaDeA�o, @DiaDeMes, @DiaDeSemana, @EsFinSemana, @EsFeriado,
@SemanaCalendario, @SemanasDelA�oLaborales, @A�oBisiesto,@Desc_DiaDeSemana,@Desc_Mes,
@Desc_Trimestre,@Desc_Fin_Semana,@Desc_Quincena_Mes) 
--incrementamos la fecha en 1
*/
SELECT @DT = DATEADD(DAY, 1, @DT)
END
GO

Execute sp_PoblarTablaTiempo

