package com.example.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

@Entity
public class clasea {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	long idclasea;
	
	@Size(min=1,max=44)
	String nombre;

	@Size(min=1,max=44)
	String tipo1;
	
	@Size(min=1,max=44)
	String tipo2;
	
	@Min(1)
	@Max(100)
	int cantidad;
	
	@Digits(integer=5,fraction=2)
	double costo;

	@Digits(integer=5,fraction=2)
	double monto;
	
	public double getMonto() {
		return monto;
	}

	public void setMonto(double monto) {
		this.monto = monto;
	}

	public long getIdclasea() {
		return idclasea;
	}

	public void setIdclasea(long idclasea) {
		this.idclasea = idclasea;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTipo1() {
		return tipo1;
	}

	public void setTipo1(String tipo1) {
		this.tipo1 = tipo1;
	}

	public String getTipo2() {
		return tipo2;
	}

	public void setTipo2(String tipo2) {
		this.tipo2 = tipo2;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public double getCosto() {
		return costo;
	}

	public void setCosto(double costo) {
		this.costo = costo;
	}
	
	
	
	
}
