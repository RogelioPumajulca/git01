package com.example.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.entity.pago;
import com.example.service.pagoService;

@Controller
public class pagoController {

	@Autowired
	pagoService pagoservice;
	
	@RequestMapping(value="/")
	public String home1(Model model){
		model.addAttribute("pago",new pago());
		return "newPago";
	}
	
	@RequestMapping(value="/venta/new",method=RequestMethod.POST)
	public String home2(@Valid pago p, BindingResult result,Model model){
		
		try {
			if (result.hasErrors()) {
				model.addAttribute("message",result.toString());
				return "newPago";
			}
			pagoservice.calculomonto(p);
			pagoservice.savepago(p);
			model.addAttribute("message","el monto es: "+p.getMonto());
			return "newPago";
			
		} catch (Exception e) {
			// TODO: handle exception
			model.addAttribute(e.getMessage());
			return "newPago";
		}
		
	}
	
	
	
	@RequestMapping(value="/pagos")
	public String listas(Model model){
		model.addAttribute("productos",pagoservice.listAllpago());
		return "pagos";
	}
	
	@RequestMapping(value="/ventas/menos100",method=RequestMethod.POST)
	public String listas2(@RequestParam double p1,@RequestParam double p2 ,Model model){
		model.addAttribute("productos",pagoservice.findByRange(p1, p2));
		return "pagos";
	}
	
	
	@RequestMapping(value="/ventas/tipolibro",method=RequestMethod.POST)
	public String listas3(@RequestParam String tipoproducto,Model model){
		model.addAttribute("cantidadtipoproductos",pagoservice.countpagoBytipoPago(tipoproducto));
		model.addAttribute("productos",pagoservice.findBytipoProducto(tipoproducto));
		return "pagos";
	}
	
	
}
