
select * from stg_Ventas order by ventas_sk

select * from stg_VentasDetalle

select * from stg_Producto

select * from Stg_Empleado

select * from stg_Tiempo


SELECT DATENAME(WEEKDAY,DiaDeSemana-1) from stg_Tiempo
--NombreDiaSemana
 
SELECT DATENAME(WEEKDAY,DiaDeMes) from stg_Tiempo

SELECT DATENAME(MONTH,tiempo_FechaActual) from stg_Tiempo
--NombreMes

SELECT DATENAME(QUARTER,tiempo_FechaActual) from stg_Tiempo
SELECT DATENAME(Q,tiempo_FechaActual) from stg_Tiempo

 
 NombreTrimestr
 NombreSemestre
 NombreQuincena
 NombreMesAnio
 NombreTrimestreAnio
 NombreSemestreAnio
 nombreQuincenaAnio

