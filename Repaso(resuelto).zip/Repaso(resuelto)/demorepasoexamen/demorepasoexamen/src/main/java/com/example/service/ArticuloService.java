package com.example.service;

import com.example.entities.Articulo;

public interface ArticuloService {
	//Guarda BD
	Articulo saveArticulo(Articulo a);

	//Lista articulos de la BD
	Iterable<Articulo> listAllArticulo();//Listar datos Articulo
	
	//Lista articulos por clavearticulos ordenados por precioventa
	Iterable<Articulo> findByClavearticuloOrderByPrecioventaDesc(int clavearticulo);
	
	//Lista articulos rango precios de la BD
	Iterable<Articulo> findByPrecioVentaRange(double pv1,double pv2);
	
	//Cuenta articulos por clave articulo 
	int countArticuloClavearticulo(int clavearticulo);
	
	
	
	//Este metodo no guarda ni lee datos de la BD
	double calcularPrecioVenta(Articulo a);
}
