package com.example.service;

import com.example.entity.clasea;

public interface claseaService {
	
	clasea saveclasea(clasea clasea);
	Iterable<clasea> listartodoclasea();
	Iterable<clasea> listarportipo1(String tipo1);
	int contarportipo1(String tipo1);
	Iterable<clasea> listarportipo2(String tipo2);
	Iterable<clasea> listarpornombre(String nombre);
	Iterable<clasea> listarporRangoprecio(double p1,double  p2);

	double calculo(clasea c);
}
