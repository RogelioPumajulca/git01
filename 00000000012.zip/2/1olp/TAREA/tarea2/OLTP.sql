

create table Categoria
(
CategoryID nvarchar(4),
CategoryName nvarchar(15),
Descripcion nvarchar(100),
)

create table Tiempo
(
tiempo_FechaActual datetime,
A�o	int,
Trimestre	int,
Mes	int,
Semana	int,
DiaDeA�o	int,
DiaDeMes	int,
DiaDeSemana	int,
EsFinSemana	int,
EsFeriado	int,
SemanaCalendario int,	
SemanaDelA�oLaboral int,
A�oBiesto int,
)


select * from Customers


drop table Categoria

select * from Tiempo


select * from Categoria

 