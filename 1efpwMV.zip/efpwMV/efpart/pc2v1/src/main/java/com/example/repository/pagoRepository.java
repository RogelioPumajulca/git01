package com.example.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.pago;

@Repository
@Transactional
public interface pagoRepository extends CrudRepository<pago, Integer>{

	@Query("select v from pago v where v.monto between ?1 and ?2")
	public List<pago> findBymontoOrderBytipoProductoAsc(double p1,double p2);
	
	@Query("select v from pago v where v.tipoproducto like ?1")
	public List<pago> findBytipoProductoOrderBymontoDesc(String t);
	
	@Query("select count(v) from pago v where v.tipoproducto like ?1")
	public int countBytipoProducto(String tipoproducto);
}
