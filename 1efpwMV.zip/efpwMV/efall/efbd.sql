CREATE DATABASE  IF NOT EXISTS `examenfinal` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `examenfinal`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: examenfinal
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clasea`
--

DROP TABLE IF EXISTS `clasea`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clasea` (
  `idclasea` bigint(20) NOT NULL AUTO_INCREMENT,
  `cantidad` int(11) NOT NULL,
  `nombre` varchar(44) DEFAULT NULL,
  `precio` double NOT NULL,
  `tipo` varchar(44) DEFAULT NULL,
  `idclaseb` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`idclasea`),
  KEY `FKd1jxcve8f8ug1ggyfyvo0u3nq` (`idclaseb`),
  CONSTRAINT `FKd1jxcve8f8ug1ggyfyvo0u3nq` FOREIGN KEY (`idclaseb`) REFERENCES `claseb` (`idclaseb`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clasea`
--

LOCK TABLES `clasea` WRITE;
/*!40000 ALTER TABLE `clasea` DISABLE KEYS */;
INSERT INTO `clasea` VALUES (1,1,'clasea1',11.11,'A',1),(2,2,'clasea2',22.22,'B',2),(3,3,'clasea3',33,'C',3),(4,4,'clasea4',44.44,'B',4),(7,5,'clasea5',55.55,'A',5),(8,6,'clasea6',66.66,'B',2);
/*!40000 ALTER TABLE `clasea` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `claseb`
--

DROP TABLE IF EXISTS `claseb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `claseb` (
  `idclaseb` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(44) DEFAULT NULL,
  `tipo` varchar(44) DEFAULT NULL,
  PRIMARY KEY (`idclaseb`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `claseb`
--

LOCK TABLES `claseb` WRITE;
/*!40000 ALTER TABLE `claseb` DISABLE KEYS */;
INSERT INTO `claseb` VALUES (1,'Peruvian Pie','A'),(2,'claseb2','C'),(3,'claseb3','B'),(4,'claseb4','B'),(5,'claseb5','C'),(6,'claseb6','A'),(7,'claseb7','B'),(8,'claseb2','A');
/*!40000 ALTER TABLE `claseb` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-24 22:20:35
