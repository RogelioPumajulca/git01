

select * from Customers
select * from Categoria
select * from Employees
select * from Products
select * from Tiempo
select * from Orders order by OrderID asc
select * from [Order Details]
