package com.example.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.entity.clasea;

@Repository
@Transactional
public interface claseaRepository extends CrudRepository<clasea, Long>{

	@Query("select c from clasea c where c.tipo like ?1")
	public List<clasea> findclaseaByTipo(String tipo);
	

	
	@Query("select c from clasea c where c.claseb.nombre like ?1")
	public List<clasea> findclaseaByclasebnombre(String clasebnombre);
	
	
	
	//no me sale ;-(
	@Query("select c from clasea c where c.claseb.idclaseb=idclaseb")
	public List<clasea> findclaseaByidclaseb(@Param("idclaseb") long idclaseb);
}
