Create Database Citas_Stage
go
Use Citas_Stage
go
Create Table STG_Paciente
( SK_Paciente		Integer identity(1,1) primary key not null,
  Cod_Paciente_OLTP		nvarchar(3),
  Nom_Paciente		nvarchar(20),
  Genero			nvarchar(20),
  Fec_Nacimiento		Datetime,
  Anyos			Integer,
  Rango_Edad		nvarchar(30),
  Estado_Paciente		nvarchar(20)
)
go
Create Table STG_Medico
(
 Sk_Medico		Integer identity(1,1) primary key not null,
 Cod_Medico_OLTP		nvarchar(3),
 Sk_Especialidad		Integer,
 Cod_Especialidad_OLTP		Nvarchar(3),
 Nom_Medico                nvarchar(20)
)
go
Create Table STG_Locales
(
 Sk_Local		Integer identity(1,1) primary key not null,
 Cod_Local_OLTP		nvarchar(3),
 Nom_Local		nvarchar(20),
 Estado_Local		nvarchar(20)
)
go
Create Table STG_Especialidad
(
 Sk_Especialidad	Integer identity(1,1) primary key not null,
 Cod_Especialidad_OLTP	nvarchar(3),
 Nom_Especialidad	nvarchar(20)
)

go

Create table STG_Tiempo
(Sk_Fecha integer identity(1,1) primary key not null,
 Fecha datetime,
 OrdenMes int, 
 NombreMes nvarchar(20),
 Anyo int
)

go
Create Table STG_Citas
(Sk_Citas		Integer identity(1,1) primary key not null,
 Cod_Citas_OLTP	nvarchar(3),
 Sk_Local		Integer,
 Sk_Medico		Integer,
 Fecha_Cita		datetime,
 Sk_FechaCita	integer,
 Duracion_Cita	Integer,
 Estado_Cita		Nvarchar(10),
 Sk_Paciente		Integer,
 Rango_Hora	nvarchar(10)
)