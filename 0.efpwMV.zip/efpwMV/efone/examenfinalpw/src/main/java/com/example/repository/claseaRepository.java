package com.example.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.clasea;

@Repository
@Transactional
public interface claseaRepository extends CrudRepository<clasea, Long>{

	@Query("select c from clasea c where c.tipo1 like ?1")
	public List<clasea> findBytipo1(String tipo1);
	
	@Query("select count(c) from clasea c where c.tipo1 like ?1")
	public int counttipo1(String tipo1);
	
	
	@Query("select c from clasea c where c.tipo2 like ?1")
	public List<clasea> findBytipo2(String tipo2);
	
	@Query("select c from clasea c where c.nombre like ?1")
	public List<clasea> findByname(String nombre);
	
	@Query("select c from clasea c where c.costo between ?1 and ?2")
	public List<clasea> findByprecioRange(double p1,double p2);
	
	
	
	
}
