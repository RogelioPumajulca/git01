package com.example.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.pago;
import com.example.repository.pagoRepository;
import com.example.service.pagoService;

@Service
public class pagoServiceImpl implements pagoService{

	@Autowired
	pagoRepository pagorepository;
	double montito;
	
	@Override
	public pago savepago(pago p) {
		// TODO Auto-generated method stub
		return pagorepository.save(p);
	}

	@Override
	public Iterable<pago> listAllpago() {
		// TODO Auto-generated method stub
		return pagorepository.findAll();
	}

	@Override
	public Iterable<pago> findByRange(double p1, double p2) {
		// TODO Auto-generated method stub
		return pagorepository.findBymontoOrderBytipoProductoAsc(p1, p2);
	}

	@Override
	public Iterable<pago> findBytipoProducto(String tipoproducto) {
		// TODO Auto-generated method stub
		return pagorepository.findBytipoProductoOrderBymontoDesc(tipoproducto);
	}

	@Override
	public int countpagoBytipoPago(String tipoproducto) {
		// TODO Auto-generated method stub
		return pagorepository.countBytipoProducto(tipoproducto);
	}

	@Override
	public double calculomonto(pago p) {
		// TODO Auto-generated method stub
		
		montito=p.getCantidad()*p.getPrecio();
		p.setMonto(montito);
		return montito;
	}

}
