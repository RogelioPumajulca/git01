

drop table stg_Categoria
drop table Stg_Cliente
drop table Stg_Empleado
drop table stg_Producto
drop table stg_Tiempo
drop table stg_Ventas
drop table stg_VentasDetalle




select * from stg_Categoria
select * from Stg_Cliente
select * from Stg_Empleado
select * from stg_Producto
select * from stg_Tiempo
select * from stg_Ventas
select * from stg_VentasDetalle




select * from stg_Cliente

select * from stg_Tiempo
select * from stg_Categoria

select * from stg_Ventas

select * from stg_VentasDetalle

DELETE FROM stg_Ventas
DBCC CHECKIDENT(stg_Ventas,0)

DELETE FROM stg_VentasDetalle
DBCC CHECKIDENT(stg_VentasDetalle,0)

DELETE FROM stg_Producto
DBCC CHECKIDENT(stg_Producto,0)

DELETE FROM stg_Categoria
DBCC CHECKIDENT(stg_Categoria,0)

DELETE FROM stg_Tiempo
DBCC CHECKIDENT(stg_Tiempo,0)

DELETE FROM Stg_Cliente
DBCC CHECKIDENT(Stg_Cliente,0)

DELETE FROM Stg_Empleado
DBCC CHECKIDENT(Stg_Empleado,0)


drop table stg_Categoria

drop table stg_Cliente

drop table Stg_Empleado

drop table stg_Producto

drop table stg_Tiempo

drop table stg_Ventas

drop table stg_VentasDetalle


CREATE TABLE [dbo].[Stg_Cliente](
	[CustomerID_sk] int IDENTITY(1,1) NOT NULL ,
	[CustomerID] [nchar](5) NOT NULL,
	[CustomerName] [nvarchar](40) NOT NULL,
	[CompanyName] [nvarchar](40) NOT NULL,
	[Address] [nvarchar](60) NULL,
	[City] [nvarchar](15) NULL,
	[Region] [nvarchar](15) NULL,
	[Country] [nvarchar](15) NULL,
	
) ON [PRIMARY]



GO
/****** Object:  Table [dbo].[Employees]    Script Date: 15/08/2016 01:17:31 p.m. ******/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Stg_Empleado](
	[EmployeeID_sk] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeID] [int]  NOT NULL,
	[LastName] [nvarchar](40) NOT NULL,
	[FirstName] [nvarchar](20) NOT NULL,
	[CompleteName] [nvarchar](70) NOT NULL,
	[Address] [nvarchar](120) NULL,
	[City] [nvarchar](15) NULL,
	[Region] [nvarchar](15) NULL,
	[Country] [nvarchar](15) NULL,
)

GO
/****** Object:  Table [dbo].[Order Details]    Script Date: 15/08/2016 01:17:31 p.m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[stg_VentasDetalle](
	[VentasDetalle_sk] [int] IDENTITY(1,1) NOT NULL,
	
	[CustomerID] [nchar](5) NULL,
	[CustomerID_sk] [int] NULL,

	[EmployeeID] [int] NULL,
	[EmployeeID_sk] [int] NULL,

	[ProductID] [int] NOT NULL,
	[ProductID_sk] [int] NOT NULL,

	[FecOrdenado_sk] [int] NULL,
	[FecRequerido_sk] [int] NULL,
	[FecEnviado_sk] [int] NULL,

	[OrderDate] [datetime] NULL,
	[RequiredDate] [datetime] NULL,
	[ShippedDate] [datetime] NULL,

	[OrderID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL ,
	[Quantity] [smallint] NOT NULL,
	
	[M_venta] [money] NOT NULL ,
	[M_Pagado] [money] NOT NULL ,
	[M_Descuento] [money] NOT NULL ,
	
)

GO
/****** Object:  Table [dbo].[Orders]    Script Date: 15/08/2016 01:17:31 p.m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[stg_Ventas](
	[ventas_sk] [int] IDENTITY(1,1) NOT NULL,
	
	[CustomerID] [nchar](5) NULL,
	[CustomerID_sk] [int] NULL,

	[EmployeeID] [int] NULL,
	[EmployeeID_sk] [int] NULL,

	[FecOrdenado_sk] [int] NULL,
	[FecRequerido_sk] [int] NULL,
	[FecEnviado_sk] [int] NULL,

	[OrderDate] [datetime] NULL,
	[RequiredDate] [datetime] NULL,
	[ShippedDate] [datetime] NULL,
	
	[OrderID] [int] NOT NULL,
	
	[M_venta] [money] NOT NULL ,
	[M_Pagado] [money] NOT NULL ,
	[M_Descuento] [money] NOT NULL ,
)

GO
/****** Object:  Table [dbo].[Products]    Script Date: 15/08/2016 01:17:31 p.m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[stg_Producto](
	[Producto_sk] [int] IDENTITY(1,1) NOT NULL,
	[ProductID] int NOT NULL,
	[ProductName] [nvarchar](80) NOT NULL,
	[ProductPrecUnit] decimal(15,2) NOT NULL,
	[Categoria_sk] int NOT NULL,
	[CategoriaNomb] [nvarchar](15) NOT NULL,
)

create table stg_Categoria
(
CategoryID_sk int IDENTITY(1,1),
CategoryID nvarchar(4),
CategoryName nvarchar(15),
)

create table stg_Tiempo
(
tiempo_sk int IDENTITY(1,1),
tiempo_FechaActual datetime,
A�o	int,
Trimestre	int,
Mes	int,
Semana	int,
DiaDeA�o	int,
DiaDeMes	int,
DiaDeSemana	int,
EsFinSemana	int,
EsFeriado	int,
SemanaCalendario int,	
SemanaDelA�oLaboral int,
A�oBiesto int,

NombreDiaSemana varchar(10),
NombreMes varchar(10),
NombreTrimestr  varchar(15),
NombreSemestre  varchar(15),
NombreQuincena  varchar(15),
NombreMesAnio   varchar(10),
NombreTrimestreAnio   varchar(15),
NombreSemestreAnio  varchar(15),
NombreQuincenaAnio   varchar(15),

)

select * from stg_Ventas







