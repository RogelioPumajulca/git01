package com.example.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.entity.clasea;
import com.example.service.claseaService;

@Controller
public class claseaController {

	@Autowired
	private claseaService claseaservice;
	double calc=0;
	@RequestMapping(value="/")
	public String home1(Model model){
		model.addAttribute("clasea",new clasea());
		return "newclasea";
		
	}
	
	@RequestMapping(value="/clasea/nuevo",method=RequestMethod.POST)
	public String home2 (@Valid clasea clasea, BindingResult result,Model model){
		
		try {
			if (result.hasErrors()) {
				model.addAttribute("message",result.toString());
				return "newclasea";
			}
			calc=claseaservice.calculo(clasea);
			claseaservice.saveclasea(clasea);
			model.addAttribute("message","el monto es: "+calc);
			return "newclasea";
		} catch (Exception e) {
			// TODO: handle exception
			model.addAttribute(e.getMessage());
			return "newclasea";
		}
		
	}	
	

	@RequestMapping(value="/clasesa")
	public String next1(Model model){
		model.addAttribute("clasesa",claseaservice.listartodoclasea());
		return "clasesa";
		
	}	
	
	
	@RequestMapping(value="/filtro1",method=RequestMethod.POST)
	public String next2(@RequestParam String tipo1,Model model){
		model.addAttribute("clasesa", claseaservice.listarportipo1(tipo1));
		model.addAttribute("cantidadtipo1",claseaservice.contarportipo1(tipo1));
		return "clasesa";
		
	}		
	

	@RequestMapping(value="/montos/menores",method=RequestMethod.POST)
	public String next3(@RequestParam double p1,@RequestParam double p2,Model model){
		model.addAttribute("clasesa",claseaservice.listarporRangoprecio(p1, p2));
		return "clasesa";
		
	}
	
	
	@RequestMapping(value="/filtronombre",method=RequestMethod.POST)
	public String next4(@RequestParam String nombre,Model model){
		model.addAttribute("clasesa",claseaservice.listarpornombre(nombre));
		return "clasesa";
		
	}	
	
	
}
