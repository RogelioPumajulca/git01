package com.example.service;

import com.example.entity.pago;

public interface pagoService {

	pago savepago(pago p);
	Iterable<pago> listAllpago();
	Iterable<pago> findByRange(double p1, double p2);
	Iterable<pago> findBytipoProducto(String tipoproducto);
	int countpagoBytipoPago(String tipoproducto);
	double calculomonto(pago p);
}
