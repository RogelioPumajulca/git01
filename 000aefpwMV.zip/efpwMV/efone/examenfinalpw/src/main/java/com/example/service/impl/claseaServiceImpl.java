package com.example.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.clasea;
import com.example.repository.claseaRepository;
import com.example.service.claseaService;

@Service
public class claseaServiceImpl implements claseaService{

	@Autowired
	private claseaRepository clasearepository;
	
	@Override
	public clasea saveclasea(clasea clasea) {
		// TODO Auto-generated method stub
		return clasearepository.save(clasea);
	}

	@Override
	public Iterable<clasea> listartodoclasea() {
		// TODO Auto-generated method stub
		return clasearepository.findAll();
	}

	@Override
	public Iterable<clasea> listarportipo1(String tipo1) {
		// TODO Auto-generated method stub
		return clasearepository.findBytipo1(tipo1);
	}

	@Override
	public int contarportipo1(String tipo1) {
		// TODO Auto-generated method stub
		return clasearepository.counttipo1(tipo1);
	}

	@Override
	public Iterable<clasea> listarportipo2(String tipo2) {
		// TODO Auto-generated method stub
		return clasearepository.findBytipo2(tipo2);
	}

	@Override
	public Iterable<clasea> listarpornombre(String nombre) {
		// TODO Auto-generated method stub
		return clasearepository.findByname(nombre);
	}

	@Override
	public Iterable<clasea> listarporRangoprecio(double p1, double p2) {
		// TODO Auto-generated method stub
		return clasearepository.findByprecioRange(p1, p2);
	}

	@Override
	public double calculo(clasea c) {
		// TODO Auto-generated method stub
		
		double montito;
		montito=c.getCosto()*c.getCantidad();
		c.setMonto(montito);
		
		return montito;
	}

	@Override
	public clasea getclaseaByIdclasea(long idclasea) {
		// TODO Auto-generated method stub
		return clasearepository.findOne(idclasea);
	}

	@Override
	public void deleteclasea(long idclasea) {
		// TODO Auto-generated method stub
		clasearepository.delete(idclasea);
	}

	
}
