package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entities.Articulo;
import com.example.repository.ArticuloRepository;

@Service
public class ArticuloServiceImpl implements ArticuloService {

	@Autowired
	private ArticuloRepository articuloRepository;
	
	
	@Override
	public Articulo saveArticulo(Articulo a) {
		// TODO Auto-generated method stub
		return articuloRepository.save(a);
	}

	@Override
	public Iterable<Articulo> listAllArticulo() {
		// TODO Auto-generated method stub
		return articuloRepository.findAll();
	}

	@Override
	public Iterable<Articulo> findByClavearticuloOrderByPrecioventaDesc(int clavearticulo) {
		// TODO Auto-generated method stub
		return articuloRepository.findByClavearticuloOrderByPrecioventaDesc(clavearticulo);
	}

	@Override
	public Iterable<Articulo> findByPrecioVentaRange(double pv1, double pv2) {
		// TODO Auto-generated method stub
		return articuloRepository.findByPrecioVenta(pv1, pv2);
	}

	@Override
	public int countArticuloClavearticulo(int clavearticulo) {
		// TODO Auto-generated method stub
		return articuloRepository.countArticuloClavearticulo(clavearticulo);
	}

	@Override
	public double calcularPrecioVenta(Articulo a) {
		double gf = 0.0;// Gasto de fabricacion
		double cp = 0.0;// Costo produccion
		double pv = 0.0;// Precio de venta
		double mo = 0.0;

		
		if (a.getClavearticulo() == 3 || a.getClavearticulo() == 4) {
			mo = a.getCostomp() * 0.75;
		} else if (a.getClavearticulo() == 1 || a.getClavearticulo() == 5) {
			mo = a.getCostomp() * 0.80;
		} else {
			mo = a.getCostomp() * 0.85;
		}

		if (a.getClavearticulo() == 2 || a.getClavearticulo() == 5) {
			gf = a.getCostomp() * 0.30;
		} else if (a.getClavearticulo() == 3 || a.getClavearticulo() == 6) {
			gf = a.getCostomp() * 0.35;
		} else {
			gf = a.getCostomp() * 0.28;
		}

		a.setGastofabricacion(gf);
		a.setCostomo(mo);
		
		cp=a.getCostomp()+mo+gf;
		a.setCostoproduccion(cp);
		pv=cp+cp*0.45;
		a.setPrecioventa(pv);
		
		return pv;
	}

}
