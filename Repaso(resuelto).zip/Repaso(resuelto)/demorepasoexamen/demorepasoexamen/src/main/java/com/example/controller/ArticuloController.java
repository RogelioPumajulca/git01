package com.example.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.entities.Articulo;
import com.example.service.ArticuloService;

@Controller
public class ArticuloController {

	@Autowired
	private ArticuloService articuloService;

	private double precioventa;

	@RequestMapping(value = "/")
	public String articulos(Model model) {
		model.addAttribute("articulo", new Articulo());
		return "newArticulo";
	}

	@RequestMapping(value = "/articulo/new", method = RequestMethod.POST) 
	public String saveArticulo(@Valid Articulo a, BindingResult result, Model model) {

		try {

			if (result.hasErrors()) {
				model.addAttribute("message", result.toString());
				return "newArticulo";
			}

			precioventa = articuloService.calcularPrecioVenta(a);
			articuloService.saveArticulo(a);
			model.addAttribute("message", "El precio de venta =" + precioventa);
			return "newArticulo";
		} catch (Exception e) {
			// TODO: handle exception
			model.addAttribute("message", e.getMessage());
			return "newArticulo";
		}

	}

	@RequestMapping(value = "/articulos") 
	public String listarticulos(Model model) {
		model.addAttribute("articulos", articuloService.listAllArticulo());
		return "articulos";// VISTA HTML
	}

	
	@RequestMapping(value = "/articulosrange", method = RequestMethod.POST) 
	public String listarticulosRange(Model model, @RequestParam double pv1, @RequestParam double pv2) {
		model.addAttribute("articulos", articuloService.findByPrecioVentaRange(pv1, pv2));
		return "articulos";// VISTA HTML
	}
	
	
	@RequestMapping(value = "/articulosclavearticulo", method = RequestMethod.POST) 
	public String listarticulosclavearticulo(Model model, @RequestParam int clavearticulo) {
		model.addAttribute("cantiarticulos", articuloService.countArticuloClavearticulo(clavearticulo));
		model.addAttribute("articulos", articuloService.findByClavearticuloOrderByPrecioventaDesc(clavearticulo));
		return "articulos";// VISTA HTML
	}
	

}
