package com.example.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.entities.Articulo;


@Repository
@Transactional
public interface ArticuloRepository extends CrudRepository<Articulo, Integer> {
  

	
}

