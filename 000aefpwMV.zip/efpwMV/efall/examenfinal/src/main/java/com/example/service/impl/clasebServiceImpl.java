package com.example.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.claseb;
import com.example.repository.clasebRepository;
import com.example.service.clasebService;

@Service
public class clasebServiceImpl implements clasebService{

	@Autowired
	clasebRepository clasebrepository;
	
	@Override
	public claseb saveclaseb(claseb claseb) {
		// TODO Auto-generated method stub
		return clasebrepository.save(claseb);
	}

	@Override
	public Iterable<claseb> listartodoclaseb() {
		// TODO Auto-generated method stub
		return  clasebrepository.findAll();
	}

	@Override
	public Iterable<claseb> listarportipo(String tipo) {
		// TODO Auto-generated method stub
		return clasebrepository.findclasebBytipo(tipo);
	}





}
