package com.example.service;

import com.example.entity.clasea;
import com.example.entity.claseb;

public interface clasebService {

	claseb saveclaseb(claseb claseb);
	Iterable<claseb> listartodoclaseb();
	Iterable<claseb> listarportipo(String tipo);
}
