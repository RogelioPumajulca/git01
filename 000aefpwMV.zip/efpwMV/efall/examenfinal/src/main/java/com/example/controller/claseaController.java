package com.example.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.entity.clasea;
import com.example.service.claseaService;
import com.example.service.clasebService;

@Controller
public class claseaController {
	
	@Autowired
	claseaService claseaservice;
	@Autowired
	clasebService clasebservice;
	
	@RequestMapping(value="/clasea", method=RequestMethod.GET)
	public String primero1(Model model){
		model.addAttribute("clasesbbb",clasebservice.listartodoclaseb());
		model.addAttribute("clasea",new clasea());
		return "newclasea";
	}
	
	@RequestMapping(value="/clasea", method=RequestMethod.POST)
	public String primero2(@Valid clasea clasea, BindingResult result ,Model model){
		
		try {
			if (result.hasErrors()) {
				model.addAttribute("clasesb",clasebservice.listartodoclaseb());
				return "newclasea";
			}

			claseaservice.saveclasea(clasea);
			//model.addAttribute("message","se guardo: "+ clasea.getNombre());
			return "newclasea";
		} catch (Exception e) {
			// TODO: handle exception
			model.addAttribute("clasesb",clasebservice.listartodoclaseb());
			return "newclasea";
		}
		
	}
	
	@RequestMapping(value="/todoclasea")
	public String primero3(Model model){
		model.addAttribute("clasesa",claseaservice.listartodoclasea());
		return "clasesa";
	}
	//ojo never call for filtroa up there
	@RequestMapping(value="/filtroa", method=RequestMethod.POST)
	public String primero4(@RequestParam String tipo,Model model){
		model.addAttribute("clasesa",claseaservice.listarclaseaPorTipo(tipo));
		return "clasesa";
	}

	//----------------
	
	
	@RequestMapping(value="/filtroab")
	public String primero5(Model model){
		model.addAttribute("clasesab",claseaservice.listartodoclasea());
		return "clasesab";
	}
		
	@RequestMapping(value="/filtroab", method=RequestMethod.POST)
	public String primero6(@RequestParam String clasebnombre,Model model){
		model.addAttribute("clasesab",claseaservice.listarclaseaPorclasebNombre(clasebnombre));
		return "clasesab";
	}
	
	
	/*
	//no me funciona ;-(
	@RequestMapping(value="/filtroab", method=RequestMethod.POST)
	public String primero60(@RequestParam long idclaseb,Model model){
		
		model.addAttribute("clasesab",claseaservice.listarclaseaPorclaseb(idclaseb));
		return "clasesab";
	}
	*/
}
