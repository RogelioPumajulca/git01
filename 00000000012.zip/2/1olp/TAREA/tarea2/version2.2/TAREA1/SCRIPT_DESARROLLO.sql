CREATE DATABASE Northwind_Stage
GO
USE [Northwind_Stage]
GO
/****** Object:  Table [dbo].[Customers]    Script Date: 15/08/2016 01:17:31 p.m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

Create TABLE Stg_Ventas(
	Ventas_SKey int identity(1,1) NOT NULL,
	Cliente_OLTP nchar(5) NULL,
	Cliente_SKey int NULL,
	Empleado_OLTP int NULL,
	Empleado_SKey int NULL,
	FecOrdenado_SKey int NULL,
	FecRequerido_SKey int NULL,
	FecEnviado_SKey int NULL,
	FecOrdenado datetime NULL,
	FecRequerido datetime NULL,
	FecEnviado datetime NULL,
	OrdenID int NULL,
	M_Venta money NULL,
	M_Pagado money NULL,
	M_Descuento money NULL 	
)

Create Table Stg_Producto (
	Producto_SKey int identity(1,1) NOT NULL,
	Producto_OLTP int NOT NULL,
	Producto_Nombre nvarchar(80) NOT NULL,
	Producto_PUnitario decimal(15,2) NULL,
	Categoria_SKey int NULL,
	Categoria_OLTP nvarchar(4) NOT NULL
)

Create Table Stg_VentasDetalle (
	VentasDet_SKey int identity(1,1) NOT NULL,
	Cliente_OLTP nchar(5) NULL,
	Cliente_SKey int NULL,
	Empleado_OLTP int NULL,
	Empleado_SKey int NULL,
	Producto_OLTP int NULL,
	Producto_SKey int NULL,
	FecOrdenado_SKey int NULL,
	FecRequerido_SKey int NULL,
	FecEnviado_SKey int NULL,
	FecOrdenado datetime NULL,
	FecRequerido datetime NULL,
	FecEnviado datetime NULL,
	OrdenID int NULL,
	PUnitario money NULL,
	Unidades int NULL,
	M_Venta money NULL,
	M_Pagado money NULL,
	M_Descuento money NULL 	
)

Create table Stg_Categoria (
	Categoria_SKey int identity(1,1) NOT NULL,
	Categoria_OLTP nvarchar(4) NOT NULL,
	Categoria_Nombre nvarchar(15) NOT NULL
) 

Create table Stg_Empleado (
	Empleado_OLTP int NOT NULL,
	Empleado_SKey int identity(1,1) NOT NULL,
	Empleado_Apellido nvarchar(40) NOT NULL,
	Empleado_Nombre nvarchar(20) NULL,
	Empleado_NombreCompleto nvarchar(70) NOT NULL,
	Empleado_Direccion nvarchar(120) NULL,
	Empleado_Ciudad nvarchar(15) NULL,
	Empleado_Region nvarchar(15) NULL,
	Empleado_Pais nvarchar(15) NULL
)

Create table Stg_Cliente (
	Cliente_SKey int identity(1,1) NOT NULL,
	Cliente_OLTP nchar(5) NOT NULL,
	Cliente_Nombre nvarchar(30) NOT NULL,
	Cliente_Compania nvarchar(40) NULL,
	Cliente_Direccion nvarchar(60) NULL,
	Cliente_Ciudad nvarchar(15) NULL,
	Cliente_Region nvarchar(15) NULL,
	Cliente_Pais nvarchar(15) NULL
)

Create table Stg_Tiempo (
	Tiempo_SKey int identity(1,1) NOT NULL,
	Tiempo_FechaActual datetime NOT NULL,
	Tiempo_Anio int NOT NULL,
	Tiempo_Trimestre int NOT NULL,
	Tiempo_Mes int NOT NULL,
	Tiempo_Semana int NOT NULL,
	Tiempo_DiaDeAnio int NOT NULL,
	Tiempo_DiaDeMes int NOT NULL,
	Tiempo_DiaDeSemana int NOT NULL,
	Tiempo_EsFinSemana int NULL,
	Tiempo_EsFeriado int NULL,
	Tiempo_SemanaCalendario int NOT NULL,
	Tiempo_SemanasDelA�oLaborales int NOT NULL,
	Tiempo_AnioBisiesto tinyint NOT NULL,
	Tiempo_Nombre_DiaDeSemana varchar(10) NULL,
	Tiempo_Nombre_Mes varchar(10) NULL,
	Tiempo_Nombre_Trimestre varchar(15) NULL,
	Tiempo_Nombre_EsFinSemana varchar(15) NULL,
	Tiempo_Nombre_Quincena varchar(15) NULL
)

select * from Stg_Cliente
select * from Stg_Categoria
select * from Stg_Empleado
select * from Stg_Tiempo order by 1
select * from Stg_Producto
select * from Stg_VentasDetalle order by 1
select * from Stg_Ventas order by 12

CREATE DATABASE Northwind_Mart
GO
USE [Northwind_Mart]
GO
/****** Object:  Table [dbo].[Customers]    Script Date: 15/08/2016 01:17:31 p.m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

Create TABLE Fact_Ventas(
	Ventas_SKey int NOT NULL,
	Cliente_SKey int NULL,
	Empleado_SKey int NULL,
	FecOrdenado_SKey int NULL,
	FecRequerido_SKey int NULL,
	FecEnviado_SKey int NULL,
	FecOrdenado datetime NULL,
	FecRequerido datetime NULL,
	FecEnviado datetime NULL,
	OrdenID int NULL,
	M_Venta money NULL,
	M_Pagado money NULL,
	M_Descuento money NULL
	Constraint PK_Fact_Ventas Primary key clustered
	(
		Ventas_SKey asc
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)on [PRIMARY]

Create Table TDim_Producto (
	Producto_SKey int NOT NULL,
	Producto_Nombre nvarchar(80) NOT NULL,
	Producto_PUnitario decimal(15,2) NULL,
	Categoria_SKey int NULL
	Constraint PK_TDim_Producto Primary key clustered
	(
		Producto_SKey asc
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)on [PRIMARY]


Create Table Fact_VentasDetalle (
	VentasDet_SKey int NOT NULL,
	Cliente_SKey int NULL,
	Empleado_SKey int NULL,
	Producto_SKey int NOT NULL,
	FecOrdenado_SKey int NULL,
	FecRequerido_SKey int NULL,
	FecEnviado_SKey int NULL,
	FecOrdenado datetime NULL,
	FecRequerido datetime NULL,
	FecEnviado datetime NULL,
	OrdenID int NULL,
	PUnitario money NULL,
	Unidades int NULL,
	M_Venta money NULL,
	M_Pagado money NULL,
	M_Descuento money NULL
	Constraint PK_Fact_VentasDetalle Primary key clustered
	(
		VentasDet_SKey asc,
		Producto_SKey asc
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)on [PRIMARY] 	


Create table TDim_Categoria (
	Categoria_SKey int NOT NULL,
	Categoria_Nombre nvarchar(15) NOT NULL
	Constraint PK_TDim_Categoria Primary key clustered
	(
		Categoria_SKey asc
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)on [PRIMARY]

Create table TDim_Empleado (
	Empleado_SKey int NOT NULL,
	Empleado_Apellido nvarchar(40) NOT NULL,
	Empleado_Nombre nvarchar(20) NULL,
	Empleado_NombreCompleto nvarchar(70) NOT NULL,
	Empleado_Direccion nvarchar(120) NULL,
	Empleado_Ciudad nvarchar(15) NULL,
	Empleado_Region nvarchar(15) NULL,
	Empleado_Pais nvarchar(15) NULL
	Constraint PK_TDim_Empleado Primary key clustered
	(
		Empleado_SKey asc
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)on [PRIMARY]


Create table TDim_Cliente (
	Cliente_SKey int NOT NULL,
	Cliente_Nombre nvarchar(30) NOT NULL,
	Cliente_Compania nvarchar(40) NULL,
	Cliente_Direccion nvarchar(60) NULL,
	Cliente_Ciudad nvarchar(15) NULL,
	Cliente_Region nvarchar(15) NULL,
	Cliente_Pais nvarchar(15) NULL
	Constraint PK_TDim_Cliente Primary key clustered
	(
		Cliente_SKey asc
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)on [PRIMARY]

Create table TDim_Tiempo (
	Tiempo_SKey int NOT NULL,
	Tiempo_FechaActual datetime NOT NULL,
	Tiempo_Anio int NOT NULL,
	Tiempo_Trimestre int NOT NULL,
	Tiempo_Mes int NOT NULL,
	Tiempo_Semana int NOT NULL,
	Tiempo_DiaDeAnio int NOT NULL,
	Tiempo_DiaDeMes int NOT NULL,
	Tiempo_DiaDeSemana int NOT NULL,
	Tiempo_EsFinSemana int NULL,
	Tiempo_EsFeriado int NULL,
	Tiempo_SemanaCalendario int NOT NULL,
	Tiempo_SemanasDelA�oLaborales int NOT NULL,
	Tiempo_AnioBisiesto tinyint NOT NULL,
	Tiempo_Nombre_DiaDeSemana varchar(10) NULL,
	Tiempo_Nombre_Mes varchar(10) NULL,
	Tiempo_Nombre_Trimestre varchar(15) NULL,
	Tiempo_Nombre_EsFinSemana varchar(15) NULL,
	Tiempo_Nombre_Quincena varchar(15) NULL
	Constraint PK_TDim_Tiempo Primary key clustered
	(
		Tiempo_SKey asc
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
)on [PRIMARY]

ALTER TABLE TDim_Producto WITH NOCHECK ADD  CONSTRAINT FK_TDim_Producto_TDim_Categoria FOREIGN KEY(Categoria_SKey)
REFERENCES TDim_Categoria (Categoria_SKey)
GO
ALTER TABLE Fact_Ventas WITH NOCHECK ADD  CONSTRAINT FK_Fact_Ventas_TDim_Empleado FOREIGN KEY(Empleado_SKey)
REFERENCES TDim_Empleado (Empleado_SKey)
GO
ALTER TABLE Fact_Ventas WITH NOCHECK ADD  CONSTRAINT FK_Fact_Ventas_TDim_Cliente FOREIGN KEY(Cliente_SKey)
REFERENCES TDim_Cliente (Cliente_SKey)
GO
ALTER TABLE Fact_Ventas WITH NOCHECK ADD  CONSTRAINT FK_Fact_Ventas_TDim_Tiempo_SKFecOrden FOREIGN KEY(FecOrdenado_SKey)
REFERENCES TDim_Tiempo (Tiempo_SKey)
GO
ALTER TABLE Fact_Ventas WITH NOCHECK ADD  CONSTRAINT FK_Fact_Ventas_TDim_Tiempo_SKFecRequ FOREIGN KEY(FecRequerido_SKey)
REFERENCES TDim_Tiempo (Tiempo_SKey)
GO
ALTER TABLE Fact_Ventas WITH NOCHECK ADD  CONSTRAINT FK_Fact_Ventas_TDim_Tiempo_SKFecEnv FOREIGN KEY(FecEnviado_SKey)
REFERENCES TDim_Tiempo (Tiempo_SKey)
GO
ALTER TABLE Fact_VentasDetalle WITH NOCHECK ADD  CONSTRAINT FK_Fact_VentasDetalle_TDim_Empleado FOREIGN KEY(Empleado_SKey)
REFERENCES TDim_Empleado (Empleado_SKey)
GO
ALTER TABLE Fact_VentasDetalle WITH NOCHECK ADD  CONSTRAINT FK_Fact_VentasDetalle_TDim_Cliente FOREIGN KEY(Cliente_SKey)
REFERENCES TDim_Cliente (Cliente_SKey)
GO
ALTER TABLE Fact_VentasDetalle WITH NOCHECK ADD  CONSTRAINT FK_Fact_VentasDetalle_TDim_Tiempo_SKFecOrden FOREIGN KEY(FecOrdenado_SKey)
REFERENCES TDim_Tiempo (Tiempo_SKey)
GO
ALTER TABLE Fact_VentasDetalle WITH NOCHECK ADD  CONSTRAINT FK_Fact_VentasDetalle_TDim_Tiempo_SKFecRequ FOREIGN KEY(FecRequerido_SKey)
REFERENCES TDim_Tiempo (Tiempo_SKey)
GO
ALTER TABLE Fact_VentasDetalle WITH NOCHECK ADD  CONSTRAINT FK_Fact_VentasDetalle_TDim_Tiempo_SKFecEnv FOREIGN KEY(FecEnviado_SKey)
REFERENCES TDim_Tiempo (Tiempo_SKey)
GO
ALTER TABLE Fact_VentasDetalle WITH NOCHECK ADD  CONSTRAINT FK_Fact_VentasDetalle_TDim_Producto FOREIGN KEY(Producto_SKey)
REFERENCES TDim_Producto (Producto_SKey)
GO

select * from TDim_Cliente
select * from TDim_Categoria
select * from TDim_Empleado
select * from TDim_Tiempo
select * from TDim_Producto
select * from Fact_Ventas
select * from Fact_VentasDetalle