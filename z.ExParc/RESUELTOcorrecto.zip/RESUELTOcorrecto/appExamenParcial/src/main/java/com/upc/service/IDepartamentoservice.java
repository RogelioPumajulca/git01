package com.upc.service;

import com.upc.dto.Departamento;

public interface IDepartamentoservice extends ICrudservice<Departamento>,IRowmapper<Departamento>{

}
