package com.upc.service;

import com.upc.dto.Empleado;

public interface IEmpleadoservice extends ICrudservice<Empleado>,IRowmapper<Empleado>{

}
