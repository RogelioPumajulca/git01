package com.example.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.claseb;

@Repository
@Transactional
public interface clasebRepository extends CrudRepository<claseb, Long>{

	@Query("select c from claseb c where c.tipo like ?1")
	public List<claseb> findclasebBytipo(String tipo);
}
