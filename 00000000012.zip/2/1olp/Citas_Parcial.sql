Create DataBase Citas_Parcial
Go
Set dateformat ymd
go
Use Citas_Parcial
go
Create Table T_Paciente
(
 Cod_Paciente     nvarchar(3) primary key,
 Nom_Paciente     nvarchar(20),
 Gen_Paciente     nvarchar(1),
 Fec_Nacimiento   datetime,
 Estado_Paciente  nvarchar(1)
)
go
Create Table T_Medico
(
 Cod_Medico	  nvarchar(3) primary key,
 Nom_Medico	  nvarchar(20),
 Cod_Especialidad nvarchar(3)
)
go
Create Table T_Locales
(
 Cod_Local	nvarchar(3) primary key,
 Nom_Local	nvarchar(20),
 Estado_Local	nvarchar(1)
)
go
Insert into T_Medico values ('M01','M�dico 1','001')
Insert into T_Medico values ('M02','M�dico 2','002')
Insert into T_Medico values ('M03','M�dico 3','003')
Insert into T_Medico values ('M04','M�dico 4','001')
Insert into T_Medico values ('M05','M�dico 5','002')
Insert into T_Medico values ('M06','M�dico 6','002')
Insert into T_Medico values ('M07','M�dico 7','001')
Insert into T_Medico values ('M08','M�dico 8','003')

Insert into T_Paciente values ('P01','Paciente 1','F','1985-01-01','A')
Insert into T_Paciente values ('P02','Paciente 2','F','1987-02-01','A')
Insert into T_Paciente values ('P03','Paciente 3','M','1984-09-21','N')
Insert into T_Paciente values ('P04','Paciente 4','M','1985-02-01','A')
Insert into T_Paciente values ('P05','Paciente 5','M','1988-01-01','A')
Insert into T_Paciente values ('P06','Paciente 6','F','1997-05-14','N')
Insert into T_Paciente values ('P07','Paciente 7','M','1990-02-01','A')
Insert into T_Paciente values ('P08','Paciente 8','F','1987-03-18','N')

Insert into T_Locales values ('01L','Local 1','0')
Insert into T_Locales values ('02L','Local 2','1')
Insert into T_Locales values ('03L','Local 3','0')
Insert into T_Locales values ('04L','Local 4','1')
Insert into T_Locales values ('05L','Local 5','0')
Insert into T_Locales values ('06L','Local 6','0')
Insert into T_Locales values ('07L','Local 7','1')
