package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entities.Articulo;
import com.example.repository.ArticuloRepository;

@Service
public class ArticuloServiceImpl implements ArticuloService {

	@Autowired
	private ArticuloRepository articuloRepository;


	@Override
	public Articulo saveArticulo(Articulo a) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<Articulo> listAllArticulo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<Articulo> findByClavearticuloOrderByPrecioventaDesc(int clavearticulo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<Articulo> findByPrecioVentaRange(double pv1, double pv2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int countArticuloClavearticulo(int clavearticulo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calcularPrecioVenta(Articulo a) {
		double gf = 0.0;// Gasto de fabricacion
		double cp = 0.0;// Costo produccion
		double pv = 0.0;// Precio de venta
		double mo = 0.0;



		return pv;
	}

}
