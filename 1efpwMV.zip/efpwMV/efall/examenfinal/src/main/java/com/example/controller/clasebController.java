package com.example.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.entity.claseb;
import com.example.service.clasebService;

@Controller
public class clasebController {

	
	@Autowired
	clasebService clasebservice;
	

	
	
	//DE ACA PARA ABAJO FUNCIONA
	@RequestMapping(value="/")
	public String segundo1(Model model){
		model.addAttribute("claseb", new claseb());
		return "newclaseb";
	}
	
	@RequestMapping(value="/claseb/nuevo",method=RequestMethod.POST)
	public String segundoxx(@Valid claseb claseb, BindingResult result){
		//public String segundo2(@Valid claseb claseb, BindingResult result,Model model){

		try {
			if (result.hasErrors()) {
				return "newclaseb";
			}
			clasebservice.saveclaseb(claseb);
			return "newclaseb";
		} catch (Exception e) {
			// TODO: handle exception
			return "newclaseb";
		}
		
	}
	
	@RequestMapping(value="/todoclaseb")
	public String segundo3(Model model){
		model.addAttribute("clasesb", clasebservice.listartodoclaseb());
		return "clasesb";
	}
	
	
	@RequestMapping(value="/filtro", method=RequestMethod.POST)
	public String segundo4(@RequestParam String tipo,Model model){
		model.addAttribute("clasesb", clasebservice.listarportipo(tipo));
		return "clasesb";
	}
	
}
