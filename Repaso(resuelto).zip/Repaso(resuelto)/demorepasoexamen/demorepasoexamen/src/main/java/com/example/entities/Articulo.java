package com.example.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

@Entity
public class Articulo {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;

	@Size(min=5,max=45)
	private String nombre;

	@Min(1)
	@Max(6)
	private int clavearticulo;

	@Digits(integer=8,fraction=2)
	private double costomp; // Costo Materia Prima

	private double costomo; // Costo Mano Obra

	private double gastofabricacion;// Gasto Fabricacion

	private double costoproduccion;// Costo Produccion

	private double precioventa;// Precio Venta

	public Articulo() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getClavearticulo() {
		return clavearticulo;
	}

	public void setClavearticulo(int clavearticulo) {
		this.clavearticulo = clavearticulo;
	}

	public double getCostomp() {
		return costomp;
	}

	public void setCostomp(double costomp) {
		this.costomp = costomp;
	}

	public double getCostomo() {
		return costomo;
	}

	public void setCostomo(double costomo) {
		this.costomo = costomo;
	}

	public double getGastofabricacion() {
		return gastofabricacion;
	}

	public void setGastofabricacion(double gastofabricacion) {
		this.gastofabricacion = gastofabricacion;
	}

	public double getCostoproduccion() {
		return costoproduccion;
	}

	public void setCostoproduccion(double costoproduccion) {
		this.costoproduccion = costoproduccion;
	}

	public double getPrecioventa() {
		return precioventa;
	}

	public void setPrecioventa(double precioventa) {
		this.precioventa = precioventa;
	}

}
