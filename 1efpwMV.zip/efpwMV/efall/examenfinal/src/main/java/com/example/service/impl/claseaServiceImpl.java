package com.example.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.clasea;
import com.example.repository.claseaRepository;
import com.example.service.claseaService;

@Service
public class claseaServiceImpl implements claseaService{

	@Autowired
	claseaRepository clasearepository;
	
	@Override
	public clasea saveclasea(clasea clasea) {
		// TODO Auto-generated method stub
		return clasearepository.save(clasea);
	}

	@Override
	public Iterable<clasea> listartodoclasea() {
		// TODO Auto-generated method stub
		return clasearepository.findAll();
	}

	@Override
	public Iterable<clasea> listarclaseaPorTipo(String tipo) {
		// TODO Auto-generated method stub
		return clasearepository.findclaseaByTipo(tipo);
	}

	@Override
	public Iterable<clasea> listarclaseaPorclasebNombre(String clasebnombre) {
		// TODO Auto-generated method stub
		return clasearepository.findclaseaByclasebnombre(clasebnombre);
	}
	
	//no me sale ;-(
	@Override
	public Iterable<clasea> listarclaseaPorclaseb(long idclaseb) {
		// TODO Auto-generated method stub
		return clasearepository.findclaseaByidclaseb(idclaseb);
	}



}
